#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import numpy as np

MAP_SIZE = 128.0
MAX_MONSTER_SPEED = 5.0
MAX_DIST_BUCKET = 5.0
MAX_FLASH_CD = 2000.0
MAX_BUFF_DURATION = 50.0

def _norm(v, v_max, v_min=0.0):
    v = float(np.clip(v, v_min, v_max))
    return (v - v_min) / (v_max - v_min) if (v_max - v_min) > 1e-6 else 0.0

class Preprocessor:
    def __init__(self):
        self.reset()

    def reset(self):
        self.step_no = 0
        self.max_step = 200
        self.last_min_monster_dist_norm = 0.5
        self.last_treasure_count = 0
        self.last_buff_count = 0
        self.last_hero_pos = None

    def feature_process(self, env_obs, last_action):
        observation = env_obs["observation"]
        frame_state = observation["frame_state"]
        env_info = observation["env_info"]
        map_info = observation["map_info"]
        legal_act_raw = observation["legal_action"]

        self.step_no = observation["step_no"]
        self.max_step = env_info.get("max_step", 200)

        hero = frame_state["heroes"]
        hero_pos = hero["pos"]
        hx, hz = hero_pos["x"], hero_pos["z"]
        
        hero_x_norm = _norm(hx, MAP_SIZE)
        hero_z_norm = _norm(hz, MAP_SIZE)
        flash_cd_norm = _norm(hero.get("flash_cooldown", 0), MAX_FLASH_CD)
        buff_remain_norm = _norm(hero.get("buff_remaining_time", 0), MAX_BUFF_DURATION)
        hero_feat = np.array([hero_x_norm, hero_z_norm, flash_cd_norm, buff_remain_norm], dtype=np.float32)

        monsters = frame_state.get("monsters", [])
        monster_feats = []
        for i in range(2):
            if i < len(monsters):
                m = monsters[i]
                is_in_view = float(m.get("is_in_view", 0))
                m_pos = m["pos"]
                if is_in_view:
                    m_x_norm = _norm(m_pos["x"], MAP_SIZE)
                    m_z_norm = _norm(m_pos["z"], MAP_SIZE)
                    m_speed_norm = _norm(m.get("speed", 1), MAX_MONSTER_SPEED)
                    raw_dist = np.sqrt((hx - m_pos["x"]) ** 2 + (hz - m_pos["z"]) ** 2)
                    dist_norm = _norm(raw_dist, MAP_SIZE * 1.41)
                else:
                    m_x_norm, m_z_norm, m_speed_norm, dist_norm = 0.0, 0.0, 0.0, 1.0
                monster_feats.append(np.array([is_in_view, m_x_norm, m_z_norm, m_speed_norm, dist_norm], dtype=np.float32))
            else:
                monster_feats.append(np.zeros(5, dtype=np.float32))

        map_feat = np.zeros(81, dtype=np.float32)
        if map_info is not None and len(map_info) >= 21:
            center = len(map_info) // 2
            flat_idx = 0
            for row in range(center - 4, center + 5):
                for col in range(center - 4, center + 5):
                    if 0 <= row < len(map_info) and 0 <= col < len(map_info[0]):
                        map_feat[flat_idx] = float(map_info[row][col] != 0)
                    flat_idx += 1

        organs = frame_state.get("organs", [])
        treasures = []
        buffs = []
        for o in organs:
            if o["status"] == 1:
                ox, oz = o["pos"]["x"], o["pos"]["z"]
                dist = np.sqrt((hx - ox)**2 + (hz - oz)**2)
                if o["sub_type"] == 1:
                    treasures.append((dist, ox, oz))
                elif o["sub_type"] == 2:
                    buffs.append((dist, ox, oz))
        
        treasures.sort(key=lambda x: x[0])
        buffs.sort(key=lambda x: x[0])
        
        treasure_feat = []
        for i in range(3):
            if i < len(treasures):
                d, ox, oz = treasures[i]
                treasure_feat.extend([_norm(ox - hx, MAP_SIZE, -MAP_SIZE), _norm(oz - hz, MAP_SIZE, -MAP_SIZE), _norm(d, MAP_SIZE * 1.41)])
            else:
                treasure_feat.extend([0.0, 0.0, 1.0])
                
        buff_feat = []
        for i in range(2):
            if i < len(buffs):
                d, ox, oz = buffs[i]
                buff_feat.extend([_norm(ox - hx, MAP_SIZE, -MAP_SIZE), _norm(oz - hz, MAP_SIZE, -MAP_SIZE), _norm(d, MAP_SIZE * 1.41)])
            else:
                buff_feat.extend([0.0, 0.0, 1.0])

        legal_action = [1] * 16
        if isinstance(legal_act_raw, list) and legal_act_raw:
            if isinstance(legal_act_raw[0], bool):
                for j in range(min(16, len(legal_act_raw))):
                    legal_action[j] = int(legal_act_raw[j])
            else:
                valid_set = {int(a) for a in legal_act_raw if int(a) < 16}
                legal_action = [1 if j in valid_set else 0 for j in range(16)]

        if sum(legal_action) == 0:
            legal_action = [1] * 16

        step_norm = _norm(self.step_no, self.max_step)
        survival_ratio = step_norm
        progress_feat = np.array([step_norm, survival_ratio], dtype=np.float32)

        feature = np.concatenate([
            hero_feat,
            monster_feats[0],
            monster_feats[1],
            map_feat,
            np.array(legal_action, dtype=np.float32),
            progress_feat,
            np.array(treasure_feat, dtype=np.float32),
            np.array(buff_feat, dtype=np.float32)
        ])

        cur_min_dist_norm = 1.0
        for m_feat in monster_feats:
            if m_feat[0] > 0:
                cur_min_dist_norm = min(cur_min_dist_norm, m_feat[4])

        survive_reward = 0.01
        dist_shaping = 0.1 * (cur_min_dist_norm - self.last_min_monster_dist_norm)

        cur_treasure_count = env_info.get("treasures_collected", 0)
        treasure_reward = 1.0 if cur_treasure_count > self.last_treasure_count else 0.0
        
        cur_buff_count = env_info.get("collected_buff", 0)
        buff_reward = 0.5 if cur_buff_count > self.last_buff_count else 0.0

        wall_penalty = 0.0
        if self.last_hero_pos is not None and last_action >= 0 and last_action <= 7:
            old_hx, old_hz = self.last_hero_pos
            if hx == old_hx and hz == old_hz:
                wall_penalty = -0.05

        self.last_hero_pos = (hx, hz)
        self.last_treasure_count = cur_treasure_count
        self.last_buff_count = cur_buff_count
        self.last_min_monster_dist_norm = cur_min_dist_norm

        reward = [survive_reward + dist_shaping + treasure_reward + buff_reward + wall_penalty]

        return feature, legal_action, reward